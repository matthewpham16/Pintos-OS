#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"

#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "devices/shutdown.h"
#include "filesys/filesys.h"
#include "threads/synch.h"
#include "threads/malloc.h"
#include "filesys/file.h"
#include <debug.h>
#include "devices/input.h"
#include "lib/user/syscall.h"
#include "userprog/process.h"

// for file synchronization
struct lock file_lock;

// Validate that a user virtual address is below PHYS_BASE and mapped
static void validate_user_pointer(void *uaddr_p) {
  // Check if address is NULL or not a user address (above PHYS_BASE in kernel virtual address)

  void* uaddr = uaddr_p;
  for (int i = 0; i < sizeof(void*); i++) {
    uaddr = (void*) (((char*) uaddr_p) + i);
    if (!uaddr || !is_user_vaddr(uaddr)) {
      // printf("bad piggy1\n");
      thread_current()->info->bad_exit = true;
      thread_exit();
    }
    // Check if address is mapped in the page directory
    if (!pagedir_get_page(thread_current()->pagedir, uaddr)) {
      // printf("bad piggy2\n");
      thread_current()->info->bad_exit = true;
      thread_exit();
    }
  }
}

void validate_user_string(const char *str) {
  while (true) {
    validate_user_pointer(str);
    if (*str == '\0')
      break;
    str++;
  }
}

void validate_user_buffer(const void *buffer, unsigned size) {
  const uint8_t *ptr;
  for (ptr = buffer; ptr < (uint8_t *)buffer + size; ptr++) {
    validate_user_pointer((void *) ptr);
  }
}

static void syscall_handler (struct intr_frame *);
int fd_add(struct file *f);
struct file *find_fd(int fd);
bool fd_remove(int fd);

void syscall_init (void)
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
  lock_init(&file_lock);
}

// helpers for fd syscall methods

// adding files
int fd_add(struct file *f) {
  struct thread *cur = thread_current();
  struct file_descriptor *fd_struct = malloc(sizeof(struct file_descriptor)); // might need to free
  if(!fd_struct){
    return -1;
}

  fd_struct-> fd = cur->next_fd;
  cur->next_fd++;
  fd_struct->file = f;
  list_push_back(&cur->fd_list, &fd_struct->elem);

  return fd_struct->fd;
}

// finding correlated fd to file
struct file *find_fd(int fd){
  struct thread *cur = thread_current();
  struct list_elem *e;

  for (e = list_begin(&cur->fd_list); e != list_end(&cur->fd_list); e = list_next(e)) {
    struct file_descriptor *fd_struct = list_entry(e, struct file_descriptor, elem);
    if (fd_struct->fd == fd){
      return fd_struct->file;
    } 
  }
  return NULL;
}

// for remove function

bool fd_remove(int fd) {
  struct thread *cur = thread_current();
  struct list_elem *e;

  for (e = list_begin(&cur->fd_list); e != list_end(&cur->fd_list); e = list_next(e)) {
    struct file_descriptor *fd_struct = list_entry(e, struct file_descriptor, elem);
    if (fd_struct->fd == fd) {
      list_remove(e);
      // lock_acquire(&file_lock);
      file_close(fd_struct->file); // given
      // lock_release(&file_lock);
      free(fd_struct);
      return true;
    }
  }
  return false;
}

static void syscall_handler (struct intr_frame *f UNUSED)
{
  // check the syscall_number before dereferencing
  validate_user_pointer((void *) f->esp);
  uint32_t syscall_number = *((uint32_t*) f->esp);

  bool success;
  int fd;
  void *buffer;
  unsigned size;
  struct file *file;
  unsigned initial_size;
  unsigned position;

  switch (syscall_number) {
    case SYS_HALT: 
      shutdown_power_off();
      break;

    case SYS_EXIT: 
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 1)); 
      int status = (int) *(((uint32_t *) f->esp) + 1);
      thread_current()->info->bad_exit = false;
      thread_current()->info->exits_gracefully = true;
      thread_current()->info->status = status;
      thread_exit();
      break;

    case SYS_EXEC: 
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 1));
      const char *cmd_line = (const char *) *(((uint32_t *) f->esp) + 1);
      validate_user_string(cmd_line);
      
      lock_acquire(&file_lock);
      thread_current()->exec_loaded = false;
      pid_t pid = process_execute(cmd_line);
      sema_down(&(thread_current()->load_sema)); // 0 -> -1

      if (thread_current()->exec_loaded)
        f->eax = pid;
      else
        f->eax = -1;

      lock_release(&file_lock);
      
      break;

    case SYS_WAIT:
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 1));
      int status_w = (int) *(((uint32_t *) f->esp) + 1);
      f->eax = process_wait(status_w);
      break;

    case SYS_CREATE: 
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 1)); 
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 2)); 

      const char *new_file = (const char *) *(((uint32_t *) f->esp) + 1);
      initial_size = (unsigned) *(((uint32_t *) f->esp) + 2);

      validate_user_string(new_file);

      // case that file name itself is null
      if(new_file==NULL){
        f->eax = false;
        break;
      }

      // file system synchronization
      lock_acquire(&file_lock);
      success = filesys_create(new_file, initial_size);
      lock_release(&file_lock);

      f->eax = success;
      break;

    case SYS_REMOVE:
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 2)); 

      const char *file_name = (const char *) (*(((uint32_t*) f->esp) + 1));
      validate_user_string(file_name);

      lock_acquire(&file_lock);
      success = filesys_remove(file_name);
      lock_release(&file_lock);

      f->eax = success;
      break;

    case SYS_OPEN: 
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 1));

      const char *filename = (const char *) *((uint32_t *) f->esp + 1);
      
      validate_user_string(filename);

      lock_acquire(&file_lock);
      struct file *open_file = filesys_open(filename);


      if(open_file==NULL){
        f-> eax=-1;
      }else{
        f->eax = fd_add(open_file);
      }
      lock_release(&file_lock);

      break;

    case SYS_FILESIZE:
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 1)); 
      fd = (int) *(((uint32_t *) f->esp) + 1);

      lock_acquire(&file_lock);
      file = find_fd(fd);

      if(file==NULL){
        f->eax = -1;
      }else{
        f->eax = file_length(file);
      }
      lock_release(&file_lock);

      break;

    case SYS_READ:
      // lock_acquire(&file_lock);
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 1)); // fd
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 2)); // buffer
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 3)); // size

      fd = (int) *(((uint32_t *) f->esp) + 1);
      buffer = (void *) *(((uint32_t *) f->esp) + 2);
      size = (unsigned) *(((uint32_t *) f->esp) + 3);

      validate_user_buffer(buffer, size);

      if(fd==0){
        for(unsigned int i=0; i<size;i++){
          *(((uint8_t *) buffer) + i) = input_getc();
        }
        f->eax = size;
        break;
      }

      lock_acquire(&file_lock);
      file = find_fd(fd);
      if(file==NULL){
        lock_release(&file_lock);
        f->eax = -1;
        break;
      }
      // lock_acquire(&file_lock);
      int bytes_read = file_read(file, buffer, size);
      f->eax = bytes_read;
      lock_release(&file_lock);
      
      break;

    case SYS_WRITE: 
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 1)); 
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 2)); 
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 3)); 
      
      fd = (int) *(((uint32_t *) f->esp) + 1);
      buffer = (const void *) *(((uint32_t *) f->esp) + 2);
      size = (unsigned) *(((uint32_t *) f->esp) + 3); 
      
      validate_user_buffer(buffer, size);

      // writing to console
      if(fd==1){
        putbuf(buffer, size);
        f->eax = size; 
        break;
      } 
      
      lock_acquire(&file_lock);
      file = find_fd(fd);
      if(file==NULL){
        lock_release(&file_lock);
        f->eax = -1;
        break;
      }

      // lock_acquire(&file_lock);
      int bytes_written = file_write(file, buffer, size);
      lock_release(&file_lock);

      f->eax = bytes_written;

      break;

    case SYS_SEEK:
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 1)); // fd
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 2)); // position

      fd = (int) *(((uint32_t *) f->esp) + 1);
      position = (unsigned) *(((uint32_t *) f->esp) + 2);

      lock_acquire(&file_lock);
      file = find_fd(fd);
      if(file==NULL){
        lock_release(&file_lock);
        break;
      }

      file_seek(file, position);
      lock_release(&file_lock);
      
      break;

    case SYS_TELL: {
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 1));

      fd = (int) *(((uint32_t *) f->esp) + 1);

      lock_acquire(&file_lock);
      file = find_fd(fd);
      if (file == NULL) {
        lock_release(&file_lock);
        f->eax = 0;  
        break;
      }

      position = file_tell(file);
      lock_release(&file_lock);

      f->eax = position; 
      break;
    }

    case SYS_CLOSE:
      validate_user_pointer((void *) (((uint32_t *) f->esp) + 1));

      fd = (int) *(((uint32_t *) f->esp) + 1);

      if (fd == 0 || fd == 1){
        break;
      }

      lock_acquire(&file_lock);
      bool remove_success = fd_remove(fd);
      lock_release(&file_lock);
      
      if(!remove_success){
        // printf("why did this not remove?"); // it should remove though? did not really give instruction what to do if not
      }
      
      break;
  }
}
